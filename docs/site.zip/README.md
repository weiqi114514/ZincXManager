# ZincXManager 官网(zxm.zincms.top)

纯静态站,没有构建步骤,零外部依赖(无 CDN / 框架 / 第三方字体):把整个目录传到服务器即生效。

## 文件清单

| 文件 | 谁维护 | 说明 |
|---|---|---|
| `index.html` | 手写 | 首页:功能 / 架构(只说明角色,不教装服务端)/ 下载入口 / 关于 |
| `zxms.html` | 手写 | **子服务端 ZXMS 部署教程**:准备、配置、首次启动、客户端接入、命令速查、常见问题 |
| `download.html` | **脚本生成** | 下载页。版本 / 大小 / SHA256 由 `_gen-site-download.ps1` 从打包产物生成 |
| `changelog.html` | **脚本生成** | 更新日志。由 `_gen-site-changelog.ps1` 读工作区的 `更新日志.md` 生成(跳过「验证」小节) |
| `assets/css/style.css` | 手写 | 全站样式(深蓝 `#0b1220` + 绿 `#22c55e`) |
| `assets/js/main.js` | 手写 | 移动端导航、复制 QQ 群号、年份 |
| `assets/img/favicon.svg` | 手写 | 站点图标(与客户端 `zxm.ico` 同一套配色) |
| `404.html` / `robots.txt` / `sitemap.xml` | 手写 | 常规 |
| `CNAME` | 手写 | **只有 GitHub Pages 需要**;宝塔上用不到,留着无害 |

> 内容口径:**项目开源(GPL-2.0),站点保留源码仓库与协议链接**。
> 但**不写"服务端怎么装、怎么构建"的步骤**:官方服务端(ZXMOS)由官方提供,官网不教;
> ZXMS(子服务端)是自建端,可以给教程、给安装包。

## 重新生成两个自动页

在工作区根目录执行:

```powershell
pwsh -NoProfile -File _build-installer.ps1      # ① 先出包:客户端 MSI + 客户端便携 ZIP + 子服务端 ZIP
pwsh -NoProfile -File _gen-site-download.ps1    # ② 再生成下载页(版本 / 大小 / SHA256 自动填)
pwsh -NoProfile -File _gen-site-changelog.ps1   # ③ 生成更新日志页(读工作区的 更新日志.md)
```

下载文件将来放在服务器上的位置由 `_gen-site-download.ps1` 的 `-DownloadBase` 决定(默认 `/downloads`)。
把安装包放进站点根目录的 `downloads/` 即可;换了目录就改这一个参数再重跑。

## 部署到宝塔(Windows 面板)

1. 把 `zxm-website\` 里的内容压成一个 zip(只压目录里的东西,不要再套一层)。
2. 宝塔 → **网站** → `zxm.zincms.top` → **文件** → 进站点根目录 → **上传** → 上传 zip → **解压**到当前目录。
3. 确认根目录能看到 `index.html`,域名绑定已是 `zxm.zincms.top`。
4. Ctrl+F5 强刷;`/`、`/download.html`、`/zxms.html`、`/changelog.html` 都要能打开。

## 本地预览

直接双击 `index.html` 就能看(file:// 也正常 —— 页面没有 fetch/ajax 依赖)。
想更接近线上,用任意静态服务器,例如 `python -m http.server 8080`。

## 改内容时的注意

- **别手改** `download.html` / `changelog.html` 里的版本号、大小、SHA256 —— 它们是生成出来的,下次重跑会被覆盖。
- 教程里写的控制台命令与配置项必须和代码一致;改了 ZXMS 的命令或配置项,记得回来核对 `zxms.html`。
- 站点内容别写"构建 / 编译 / 克隆仓库"这类步骤。
